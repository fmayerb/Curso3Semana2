package mx.com.mayernet.tareacurso3semana2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    EditText evNombre;
    DatePicker dpFechaNacimiento;
    EditText evDescripcion;
    EditText evTelefono;
    EditText evEmail;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        //Bundle parametros = getIntent().getExtras();
        //String nombre = parametros.getString("NombreContacto");
        //String telefono = parametros.getString("TelefonoContacto");
        //String email = parametros.getString("emailContacto");

         evNombre = (EditText) findViewById(R.id.etNombre1);
         dpFechaNacimiento = (DatePicker) findViewById(R.id.datePicker1);
         evDescripcion = (EditText) findViewById(R.id.etDescripcion1);
         evTelefono = (EditText) findViewById(R.id.etTelefono1);
         evEmail = (EditText) findViewById(R.id.etEmail1);

            Bundle parametros = getIntent().getExtras();
            if(parametros != null) {
                evNombre.setText(parametros.getString("NombreContacto"));
                evDescripcion.setText(parametros.getString("DescripcionContacto"));
                evTelefono.setText(parametros.getString("TelefonoContacto"));
                evEmail.setText(parametros.getString("EmailContacto"));
                //int myYear = 0;
                //int myMonth = 0;
                //int myDay = 0;
                //myDay = Integer.parseInt(dpFechaNacimiento.toString().substring(0,2));
                //myMonth = Integer.parseInt(dpFechaNacimiento.toString().substring(4,5));
                //myYear = Integer.parseInt(dpFechaNacimiento.toString().substring(7,10));
                //dpFechaNacimiento.updateDate(myYear,myMonth,myDay);
            }
        Button miBoton = (Button)findViewById(R.id.button1);
        miBoton.setOnClickListener(new Button.OnClickListener()
        {
            @Override
            public void onClick(View v) {

                //TextView tvNombre1 = (TextView) v.findViewById(R.id.txNombre);
//                String passingdata = evNombre.getText().toString();
                Intent intent = new Intent(MainActivity.this, ConfirmaDatos.class);
//                Bundle b = new Bundle();
//                b.putString("NombreContacto", passingdata);
//                intent.putExtras(b);
                String day = dpFechaNacimiento.getDayOfMonth() + "";
                String month = (dpFechaNacimiento.getMonth() + 1)+ "";
                int year = dpFechaNacimiento.getYear();
                String day1 = "00".substring(day.length()) + day;
                String month1 = "00".substring(month.length()) + month;
                String myDate = day1 +"/"+month1+"/"+year;

                Intent nombreContacto = intent.putExtra("NombreContacto", evNombre.getText().toString());
                Intent telefonoContacto = intent.putExtra("TelefonoContacto", evTelefono.getText().toString());
                Intent emailContacto = intent.putExtra("EmailContacto", evEmail.getText().toString());
                Intent descripcionContacto = intent.putExtra("DescripcionContacto", evDescripcion.getText().toString());
                Intent fechaNacimientoContacto = intent.putExtra("FechaNacimientoContacto", myDate);
                startActivity(intent);
                //finish();

            }
            }
        );




    }
}
