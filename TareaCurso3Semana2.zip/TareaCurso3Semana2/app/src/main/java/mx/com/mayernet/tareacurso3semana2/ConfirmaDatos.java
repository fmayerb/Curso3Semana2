package mx.com.mayernet.tareacurso3semana2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class ConfirmaDatos extends AppCompatActivity {

    TextView tvNombre;
    TextView tvFechaNacimiento;
    TextView tvDescripcion;
    TextView tvTelefono;
    TextView tvEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirma_datos);


        Bundle parametros = getIntent().getExtras();
        String nombre = parametros.getString("NombreContacto");
        String telefono = parametros.getString("TelefonoContacto");
        String email = parametros.getString("EmailContacto");
        String descripcion = parametros.getString("DescripcionContacto");
        String fechaNacimiento = parametros.getString("FechaNacimientoContacto");

         tvNombre = (TextView) findViewById(R.id.txNombre);
         tvFechaNacimiento = (TextView) findViewById(R.id.txFechaNacimiento);
         tvDescripcion = (TextView) findViewById(R.id.txDescripcion);
         tvTelefono = (TextView) findViewById(R.id.txTelefono);
         tvEmail = (TextView) findViewById(R.id.txEmail);

        tvNombre.setText(nombre);
        tvTelefono.setText(telefono);
        tvEmail.setText(email);
        tvDescripcion.setText(descripcion);
        tvFechaNacimiento.setText(fechaNacimiento);


        Button buttonX = (Button)findViewById(R.id.btEditaDatos);
        buttonX.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v)
            {
                //DO SOMETHING! {RUN SOME FUNCTION ... DO CHECKS... ETC}

                Intent intent  =new Intent(ConfirmaDatos.this, MainActivity.class);
                intent.putExtra("NombreContacto",tvNombre.getText().toString());
                intent.putExtra("TelefonoContacto",tvTelefono.getText().toString());
                intent.putExtra("DescripcionContacto",tvDescripcion.getText().toString());
                intent.putExtra("EmailContacto",tvEmail.getText().toString());
                intent.putExtra("FechaNacimientoContacto",tvFechaNacimiento.getText().toString());
                //intent.putExtra("NombreContacto",contactos.get(position).getNombreContacto());
                //intent.putExtra("TelefonoContacto",contactos.get(position).getTelefonoContacto());
                //intent.putExtra("emailContacto",contactos.get(position).getEmailContacto());
                startActivity(intent);

            }
        });
    }
}
